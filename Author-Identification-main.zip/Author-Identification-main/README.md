# Author-Identification
The Author Identification is being used for forensic analysis and humanities to identify the author of anonymous text used for communication.
